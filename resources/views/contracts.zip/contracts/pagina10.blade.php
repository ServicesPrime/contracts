<!-- ====== PÁGINA 10 - COMPLETION CERTIFICATE AND CLEANING REFERENCE ====== -->
<div class="page">
@php
$watermarkPath = storage_path('app/public/Prime.png');
$watermark64 = file_exists($watermarkPath)
    ? 'data:image/png;base64,' . base64_encode(file_get_contents($watermarkPath))
    : '';
@endphp

    <!-- Marca de agua de fondo -->
    @if($watermark64)
    <div style="
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        z-index: 1;
        opacity: 0.05;
        pointer-events: none;
    ">
        <img src="{{ $watermark64 }}" alt="Watermark" style="width: 1200px; height: auto;">
    </div>
    @endif

    <div class="content content-with-padding" style="position: relative; z-index: 2;">
        
        <h2 class="service-areas-title">CLAUSE – COMPLETION CERTIFICATE AND CLEANING REFERENCE</h2>

        <p>With the aim of establishing a clear and shared reference point for the level of cleanliness achieved, upon completion of the Initial Deep Cleaning Service it is recommended that both parties sign a <strong>Completion Certificate</strong>. This document may include a photographic report and/or a checklist showing the condition of the premises at that time.</p>

        <p>Such certificate will serve as the baseline reference for the quality and cleanliness level to be maintained during the regular service, thus facilitating continuous monitoring and evaluation.</p>

        <p>The <strong>CLIENT's</strong> signature on the Completion Certificate will confirm that the Initial Deep Cleaning Service has been carried out as planned and that the level achieved is recognized as the reference standard for subsequent maintenance.</p>
        
    </div>
</div>

<!-- Footer fijo global -->
<div class="footer">
    <div class="site-footer">
        <div class="footer-red"></div>
        <div class="footer-blue">
            8303 Westglen Dr ~ Houston, TX 77063 ~ Phone 713-338-2553 ~ Fax 713-574-3065<br>
            www.primefacilityservicesgroup.com
        </div>
    </div>
</div>